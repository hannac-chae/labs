package product.vo;

/**
 * (1) int min, int max 두 개의 멤버변수를 선언
 * (2) 기본생성자 생성
 * (3) 접근자, 수정자 생성
 * (4) equals() & hashCode() : 두 값 모두로 작성
 * (5) toString() 작성
 *   : "검색가격[최저가:얼마 ~ 최대가:얼마]" 와 같은 문자열이 출력되도록 작성 
 * @author 304
 *
 */
public class Price {

}
