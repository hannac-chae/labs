package vo;


//TODO 빈즈 규격의 클래스로 작성할 것
public class Tea {
	
	// 멤버변수
	// -name : String : 차의 이름 변수
	// -material : String : 차의 재료 이름
	// -isFermented : boolean : 발효차인지 여부
	
	
	// hashCode, equals : name 기준 재정의
	// toString() 재정의

}
