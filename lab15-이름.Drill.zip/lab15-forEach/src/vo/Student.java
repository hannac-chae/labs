package vo;

//TODO 빈즈 규격의 클래스로 작성할 것
public class Student {
	
	// 멤버변수
	// -stdNo : String : 학번 변수 S001, S002 로 증가  
	// -stdName : String : 학생 이름 변수
	// -major : String : 전공명 변수

	// hashCode, equals : stdNo 기준 재정의
	
	// toString() 재정의


}
