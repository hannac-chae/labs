package vo;


//TODO 빈즈 규격의 클래스로 작성할 것
public class SmartPhone {
	
	// 멤버변수
	// -name : String : 모델명 변수
	// -manufacturer : String : 제조사 변수
	// -memory : double : 내장 메모리 크기
	// -storage : double : 내장 스토리지 크기
	// -cameraPixel : double : 카메라 화소 수
	// -screen : double : 스크린 inch 크기
	// -isEmbededBattery : boolean : 배터리가 내장형인지 교체형인지 여부
	
	// hashCode, equals : 모델명 기준 재정의
	// toString() 재정의
}
