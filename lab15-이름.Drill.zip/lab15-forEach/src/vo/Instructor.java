package vo;

//TODO 빈즈 규격의 클래스로 작성할 것
public class Instructor {
	
	// 멤버변수
	// -insNo : String : 강사번호 변수 INS001, INS002 로 증가  
	// -insName : String : 강사 이름 변수
	// -subject : String : 강의과목 변수

	// hashCode, equals : insNo 기준 재정의
	
	// toString() 재정의

}
