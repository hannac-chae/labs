package vo;

// TODO 빈즈규격의 클래스로 작성할 것
public class Coffee {
	
	// 멤버변수 
	// -origins : List<String> : 커피 원산지명를 타나내는 리스트 변수 
	
	// -acidity : int : 커피 산도를 나타내는 변수 1 ~ 100 사이 값을 가짐 
	
	// -isBlending : boolean : 커피 블랜딩인지 싱글오리진인지 여부를 타나내는 변수  

	// toString() 재정의
}
