package vo;

// TODO 빈즈 규격의 클래스로 작성할 것
public class Employee {

	// 멤버변수
	// -empNo : String : 사번 변수 E001, E002 로 증가  
	// -empName : String : 사원 이름 변수
	// -dept : String : 부서명

	// hashCode, equals : empNo 기준 재정의
	
	// toString() 재정의
}
