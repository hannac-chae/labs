package drill;

public class ForEachDrill {

	public static void main(String[] args) {

		printFruits();
		
		printStarNames();
		
		printTeas();
		
		printSmartPhones();
		
		printCoffees();
		
		printColors();
		
		printStudents();
		
		printEmployees();
		
		printInstructors();
		
	}
	
	
	/**
	 * 메소드명 printFruits
	 * 1. 과일이름 다섯개를 String 으로 생성하고 그 인스턴스 저장하는 목록 생성
	 * 2. foreach 로 출력
	 * 
	 * @param 없음
	 * @return 없음
	 */

	
	
	
	/**
	 * 메소드명 printStarNames
	 * 1. 연예인 이름 다섯개를 String 으로 생성하고 그 인스턴스 저장하는 목록 생성
	 * 2. foreach 로 출력
	 * @param 없음
	 * @return 없음
	 */
	
	
	
	
	/**
	 * 메소드명 printTeas
	 * 1. Tea 타입의 인스턴스 2개를 생성하고 그 인스턴스 저장하는 목록 생성
	 * 2. 목록에 저장된 Tea 타입의 데이터를 foreach 로 출력
	 * @param 없음
	 * @return 없음
	 */
	
	
	
	
	/**
	 * 메소드명 printSmartPhones
	 * 1. SmartPhone 타입의 인스턴스 2개를 생성하고 그 인스턴스 저장하는 목록 생성
	 * 2. 목록에 저장된 SmartPhones 타입의 데이터 foreach 로 출력
	 * @param 없음
	 * @return 없음
	 */
	
	
	
	
	/**
	 * 메소드명 printCoffees
	 * 1. Coffee 타입의 인스턴스 2개를 생성하고 그 인스턴스 저장하는 목록 생성
	 * 2. foreach 로 출력
	 * @param 없음
	 * @return 없음
	 */
	
	
	
	
	/**
	 * 메소드명 printColors
	 * 1. 색깔이름 다섯개를 String 으로 생성하고 그 인스턴스 저장하는 목록 생성
	 * 2. foreach 로 출력
	 * @param 없음
	 * @return 없음
	 */
	
	
	
	
	/**
	 * 메소드명 printStudents
	 * 1. Student 타입의 인스턴스 다섯개를 생성하고 그 인스턴스 저장하는 목록 생성
	 * 2. foreach 로 출력
	 * @param 없음
	 * @return 없음
	 */
	
	
	
	
	/**
	 * 메소드명 printEmployees
	 * 1. Employee 타입의 인스턴스 세개를 생성하고 그 인스턴스 저장하는 목록 생성
	 * 2. foreach 로 출력
	 * @param 없음
	 * @return 없음
	 */
	
	
	
	
	/**
	 * 메소드명 printInstructors
	 * 1. Instructor 타입의 인스턴스 세개를 생성하고 그 인스턴스 저장하는 목록 생성
	 * 2. foreach 로 출력
	 * @param 없음
	 * @return 없음
	 */
	
	
	
	
}
